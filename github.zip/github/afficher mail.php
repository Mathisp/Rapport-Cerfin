<script async>
    console.log("Hello World");
    //On définit des variables qui récupèrent les élèments contenu dans les champs du formulaire
    //On selectionne les champs en fonction de leurs noms dans le code HTML
    var NomCandidat = document.getElementsByClassName("js-candidat-name")[0].getElementsByTagName("select")[0];
    var NomCandidat2 = document.getElementsByClassName("js-candidat-name")[0].getElementsByTagName("span")[0];
    
    var civi = document.getElementsByClassName("js-civi")[0].getElementsByTagName("input")[0];
    var userDN = document.getElementsByClassName("js-user-DN")[0].getElementsByTagName("input")[0];
    
    var PostePourvoir = document.getElementsByClassName("js-poste")[0].getElementsByTagName("select")[0];
    var AutrePoste = document.getElementsByClassName("js-poste1")[0].getElementsByTagName("input")[0];
    
    var EmailCandidat = document.getElementsByClassName("js-mail-du-candidat")[0].getElementsByTagName("input")[0];
    var EmailConfirmation = document.getElementsByClassName("js-confirmation-email")[0].getElementsByTagName("input")[0];
    
    var radio1 = document.getElementsByClassName("js-radio")[0].getElementsByTagName("input")[0];
    var radio2 = document.getElementsByClassName("js-radio")[0].getElementsByTagName("input")[1];
    var radio3 = document.getElementsByClassName("js-radio")[0].getElementsByTagName("input")[2];
    var radio4 = document.getElementsByClassName("js-radio")[0].getElementsByTagName("input")[3];
    
    var CivilitéEntretien = document.getElementsByClassName("js-civilité1")[0].getElementsByTagName("select")[0];
    var NomEntretien = document.getElementsByClassName("js-entretien-name")[0].getElementsByTagName("input")[0];
    var PosteEntretien = document.getElementsByClassName("js-entretien-poste")[0].getElementsByTagName("input")[0];
    
    var DateEntretien = document.getElementsByClassName("js-date")[0].getElementsByTagName("input")[0];
    var HeureEntretien = document.getElementsByClassName("js-heure")[0].getElementsByTagName("input")[0];
    var MinuteEntretien = document.getElementsByClassName("js-heure")[0].getElementsByTagName("input")[1];
    
    var CivilitéContact = document.getElementsByClassName("js-civilité2")[0].getElementsByTagName("select")[0];
    var NomContact = document.getElementsByClassName("js-contact-name")[0].getElementsByTagName("input")[0];
    var TelContact = document.getElementsByClassName("js-contact-tel")[0].getElementsByTagName("input")[0];
    
    var textGeneral = document.getElementsByClassName("js-textarea")[0].getElementsByTagName("textarea")[0];
    
    var previewTextGeneral = document.getElementById("preview-text-general");
   
    
    NomCandidat.addEventListener("input", updateText);
    NomCandidat.setAttribute("onchange", "updateTextDelay()");
    
    PostePourvoir.addEventListener("input", updateText);
    AutrePoste.addEventListener("input", updateText);
    
    EmailCandidat.addEventListener("input", updateText);
    EmailConfirmation.addEventListener("input", updateText);
    
    radio1.addEventListener("change", updateText);
    radio2.addEventListener("change", updateText);
    radio3.addEventListener("change", updateText);
    radio4.addEventListener("change", updateText);
    
    CivilitéEntretien.addEventListener("input", updateText);
    NomEntretien.addEventListener("input", updateText);
    PosteEntretien.addEventListener("input", updateText);
    
    DateEntretien.addEventListener("input", updateText);
    DateEntretien.setAttribute("onchange", "updateText()");
    HeureEntretien.addEventListener("input", updateText);
    MinuteEntretien.addEventListener("input", updateText);
    
    CivilitéContact.addEventListener("input", updateText);
    NomContact.addEventListener("input", updateText);
    TelContact.addEventListener("input", updateText);
   
    textGeneral.addEventListener("input", updatePreview);
    
   
    console.log("js-candidat-name.value : "+NomCandidat.value);
    console.log("NomCandidat2.innerHTML : "+NomCandidat2.innerHTML);
    
    updateText();
    updatePreview();
    
    function updateText(){
        //On écrit "Monsieur" ou "Madame" en fonction du genre de l'employé
        console.log("js-candidat-name.value : "+NomCandidat.value);
        console.log("NomCandidat2.innerHTML : "+NomCandidat2.innerHTML);
        console.log("updateText()");
        console.log("Civi : "+civi.value);
        let madameOuMonsieur = "Monsieur";
        if(civi.value == "Mme" || civi.value == "Mle"){
            console.log("in crit if");
            madameOuMonsieur = "Madame";
        }else{
            madameOuMonsieur = "Monsieur";
        }
        console.log("DN:"+userDN.value);
        //On choisit le texte a afficher en fonction du choix de l'utilisateur
        //On affiche les variable dans le texte pour personnaliser le mail selon les champs du formulaire
        if(radio1.checked){
            textGeneral.value = madameOuMonsieur+",\n\nNous avons bien reçu votre offre de candidature au sein de notre entreprise à un poste de "+PostePourvoir.value+" et nous vous en remercions.\n\nAfin d'examiner celle-ci de façon plus approfondie, nous souhaiterions vous rencontrer.\n\nEn conséquence, nous vous proposons de rencontrer "+CivilitéEntretien.value+" "+NomEntretien.value+", notre "+PosteEntretien.value+" le "+DateEntretien.value+" à "+HeureEntretien.value+"h"+MinuteEntretien.value+".\n\nSi cette date ne vous convenait pas, vous voudrez bien contacter "+CivilitéContact.value+" "+NomContact.value+" tél. : "+TelContact.value+", afin de convenir d’un autre rendez-vous.\n\nVeuillez agréer, "+madameOuMonsieur+", nos salutations distinguées.\n\nLa direction.";
        }
        else if(radio2.checked){
            textGeneral.value = madameOuMonsieur+",\n\nNous avons bien reçu votre offre de candidature au sein de notre entreprise à un poste de "+PostePourvoir.value+" et nous vous en remercions.\n\nAfin d'examiner celle-ci de façon plus approfondie, nous souhaiterions vous rencontrer.\n\nEn conséquence, nous vous invitons à prendre contact avec "+CivilitéContact.value+" "+NomContact.value+" tél. : "+TelContact.value+", afin de convenir d’un rendez-vous.\n\nVeuillez agréer, "+madameOuMonsieur+", nos salutations distinguées.\n\nLa direction.";
        }
        else if(radio3.checked){
            textGeneral.value = madameOuMonsieur+",\n\nNous avons bien reçu votre offre de candidature au sein de notre entreprise à un poste de "+PostePourvoir.value+" et nous vous en remercions.\n\nNous l'avons examinée avec attention, mais, malgré tout l'intérêt qu'elle présente, nous sommes au regret de vous informer que nous ne disposons actuellement d'aucun poste susceptible de convenir à votre profil professionnel.\n\nVous souhaitant de trouver rapidement un emploi convenant mieux à vos qualités professionnelles,\n\nNous vous prions d'agréer, "+madameOuMonsieur+", nos salutations distinguées.\n\nLa direction.";
        }
        else if(radio4.checked){
           textGeneral.value = madameOuMonsieur+",\n\nNous avons bien reçu votre offre de candidature au sein de notre entreprise à un poste de "+PostePourvoir.value+" et nous vous en remercions.\n\nNous l'avons examinée avec attention, mais, malgré tout l'intérêt qu'elle présente, nous sommes au regret de vous informer que nous ne pouvons y donner une suite favorable, en effet, d'autres candidats présentent des caractéristiques professionnelles plus adaptées au poste à pourvoir.\n\nNous vous prions d'agréer, "+madameOuMonsieur+", nos salutations distinguées.\n\nLa direction.";
        }
        else{
            textGeneral.value = "";
        }
        updatePreview();
    }
    //Affichage de l'email en même temps que l'on complète le formulaire
    function updatePreview(){
        console.log("updatePreview()");
        console.log(EmailConfirmation.value);
        previewTextGeneral.innerHTML = textGeneral.value;
    }
    function updateTextDelay(){
        setTimeout(() => { updateText() }, 50);
    }
</script>