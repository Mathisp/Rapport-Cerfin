<?php   
    /**
     * Template Name: PDF justificatif d'absence sans réponse
     * Version: 0.1
     * Description: Template PDF format lettre
     * Author: Mathis Permanne
     * Author URI: 
     * Group: CERFIN
     * License: 
     * Required PDF Version: 4.0
     * Tags: Lettre, PDF, Cerfin, Absence
     */

    $f = $form_data['field'];
//On nomme des variables et on leurs associe les valeurs des champs du formulaire
    $nom_utilisateur = $f[29];
    $prenom_utilisateur = $f[28];
    $qualité_utilisateur = $f[39];
    $date_du_jour = $f[38];

    $enseigne_etablissement = $f[18];
    $categorie_juridique_etablissement = $f[43];
    $adresse_etablissement = $f[19];
    $complement_adresse_etablissement = $f[20];
    $code_postal_etablissement = $f[21];
    $ville_etablissement = $f[22];
    $SIRET_etablissement = $f[23];

    $civilite_salarie = $f[44];
    $nom_salarie = $f[45];
    $prenom_salarie = $f[24];
    $adresse_salarie = $f[31];
    $complement_adresse_salarie = $f[32];
    $code_postal_salarie = $f[33];
    $ville_salarie = $f[34];
    $date_debut_absence = $f[37];
//On nomme une variable et on la définie comme la concaténation de deux autres
    $nom_magasin = $enseigne_etablissement." ".$categorie_juridique_etablissement;
 ?>

<style>
On applique à tout le texte le thème "Times New Roman"
*{
    font-family: "Times New Roman"
}
La balise "p" permet de gèrer la police du texte et l'interligne
p{
    font-size: 13;
    line-height: 1px;
}
La classe ".line-spicing" change l'interligne 
.line-spacing{
    line-height: 20px;
}
.center-text{
    text-align: center;
}
.pdf-body{
    padding-left: 2cm;
    padding-right: 2cm;
}
.right-text{
    text-align: right;
}
</style>
On ecrit le texte de la lettre en mettant les balises et classe adpater pour gerer la mise en forme.
On ajoute des variable dans le texte pour afficher les valeurs des champs du formulaire
 <div class="pdf-body">
    <br>
    <br>
    <br>
    <p><?php echo $nom_magasin ?></p>
    <p><?php echo $adresse_etablissement ?> <?php echo $complement_adresse_etablissement ?></p>
    <p><?php echo $code_postal_etablissement ?> <?php echo $ville_etablissement ?></p>
    <p>SIRET: <?php echo $SIRET_etablissement ?></p>
    <p class="right-text"><?php echo $civilite_salarie ?> <?php echo $prenom_salarie ?> <?php echo $nom_salarie ?></p>
    <p class="right-text"><?php echo $adresse_salarie ?> <?php echo $complement_adresse_salarie ?></p>
    <p class="right-text"><?php echo $code_postal_salarie ?> <?php echo $ville_salarie ?></p>
    <br>
    <p>Lettre recommandée avec AR</p>
    <p class="right-text">A <?php echo $ville_etablissement ?></p>
    <p class="right-text">Le <?php echo $date_du_jour ?></p>
    <br>
    <br>
    <br>
    <br>
    <br>
    <p><?php echo $civilite_salarie ?> <?php echo $prenom_salarie ?> <?php echo $nom_salarie ?>,</p>
    <br>
    <p class="line-spacing">Vous avez été absent(e) de l'entreprise, et ce, sans aucune justification, à partir du <?php echo $date_debut_absence ?>.</p>
    <p class="line-spacing">Vous n'avez à ce jour, produit aucun certificat médical justifiant cette absence.</p>
    <p class="line-spacing">Nous vous mettons donc en demeure, soit de nous fournir, dans les vingt-quatre heures, un certificat médical conforme à la réglementation, soit de justifier par écrit votre absence.</p>
    <p class="line-spacing">Sans réponse de votre part à cette mise en demeure, nous considérons que votre absence est injustifiée et nous nous verrons contraints d'en tirer les conséquences qui s'imposent.</p>
    <p class="line-spacing">Veillez agréer, <?php echo $civilite_salarie ?> <?php echo $prenom_salarie ?> <?php echo $nom_salarie ?>, nos salutations distinguées.</p>
    <br>
    <p class="center-text"><?php echo $prenom_utilisateur ?> <?php echo $nom_utilisateur ?></p>
    <p class="center-text"><?php echo $qualité_utilisateur ?></p>
 </div>