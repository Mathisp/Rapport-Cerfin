Sub naviguersite()


Dim IE As Object
Set IE = CreateObject("InternetExplorer.Application")
IE.Visible = True
IE.Navigate "https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:Accueil_principal"


'On pointe le membre Document
'Set IEDoc = IE.Document

'On pointe la Zone Titre
Set InputZoneTexte = IEDoc.all("q")

'On définit le texte que l'on souhaite placer à l'intérieur
InputZoneTexte.Value = Sheets("Accueil").Cells(9, 14)

Do Until IE.readyState = 4
DoEvents
Loop

IE.document.getElementById("searchInput").Value = Sheets("Accueil").Cells(9, 14)
IE.document.getElementById("searchInput").Select
Application.SendKeys "~", True
Application.Wait (Now + TimeValue("0:00:05"))

IE.document.getElementById("searchInput").Value = "google"
IE.document.getElementById("searchInput").Select
Application.SendKeys "~", True


'VBA.Shell "C:\Users\l.bosqui\AppData\Local\Mozilla Firefox\firefox.exe"
'Application.Wait (Now + TimeValue("0:00:02"))
'SendKeys "monportail.pro"
'SendKeys "~"
'Application.Wait (Now + TimeValue("0:00:01"))

End Sub

Sub ListeDeroulante()




'Selectionner une valeur dans une liste déroulante
Dim IE As New InternetExplorer
    'Ouvre la page Web
   IE.Navigate "http://www.cadastre.gouv.fr/scpc/accueil.do"
   IE.Visible = True
   WaitIE IE



 Dim htmlSelectElem As HTMLSelectElement
 Dim html As HTMLSelect


Do Until IE.readyState = 4
DoEvents
Loop

Set htmlSelectElem = IE.document.all("indiceRepetition")
htmlSelectElem.Value = "T"

'Set htmlSelectElem = IE.document.all("codeDepartement")
'html.Value = "001"

IE.document.getElementById("lieuDit").Value = Sheets("Accueil").Cells(26, 2)


End Sub

Sub connection()



Set IE = CreateObject("InternetExplorer.Application")
'Affichage de la fenêtre IE
IE.Visible = True

'On recherche le site web
IE.Navigate "monportail.pro"
 
Application.Wait (Now + TimeValue("0:00:03"))

Do Until IE.readyState = 4
DoEvents
Loop

'on ecrit l'identifiant


IE.document.getElementById("acdCode").Value = Sheets("Accueil").Cells(10, 14)
Application.Wait (Now + TimeValue("0:00:01"))

'on écrit le mot de passe
IE.document.getElementById("acdPass").Value = Sheets("Accueil").Cells(32, 2)
IE.document.forms(0).submit
Application.Wait (Now + TimeValue("0:00:03"))

IE.document.getElementById("icon-IPAIE-0").Click
Application.Wait (Now + TimeValue("0:00:02"))






End Sub


Private Sub CommandButton22_Click()

Dim IEDoc As HTMLDocument

Dim winShell As Object
Const stURL As String = "https://monportail.pro/isuiteexpert/pages/ipaie/ipaie.html"
Set winShell = CreateObject("Shell.Application")

For Each IE In winShell.Windows
    If IE.LocationURL = stURL Then Exit For
Next IE
If Not IE Is Nothing Then
 
Do Until IE.readyState = 4
DoEvents
Loop

Set IEDoc = IE.document 'recupere le code de la page

With IEDoc
With .getElementById("titre")


            .Click  'simule un click sur le champs
            .Focus  'active le champs
            .Value = "P3"  'set la valeur du champ ex "26/05/2022" ou ou "P3" pour madame par rapport a ta photo

End With
End With


'Set htmlSelectElem = IE.document.getElementById("titre")
'     htmlSelectElem.Value = "P3"
'Set opt = htmlSelectElem.document.getElementById("paysNaiss")
'     htmlSelectElem.Value = "212"


'Set IE = CreateObject("InternetExplorer.Application")
''Affichage de la fenêtre IE
'IE.Visible = True
''On recherche le site web
'IE.Navigate "monportail.pro"
'Application.Wait (Now + TimeValue("0:00:03"))


'on ecrit l'identifiant

'
'IE.Document.getElementById("acdCode").Value = Sheets("Accueil").Cells(10, 14)
'Application.Wait (Now + TimeValue("0:00:01"))
'
''on écrit le mot de passe
'IE.Document.getElementById("acdPass").Value = Sheets("Accueil").Cells(32, 2)
'IE.Document.forms(0).submit
'Application.Wait (Now + TimeValue("0:00:03"))
'
'IE.Document.getElementById("icon-IPAIE-0").Click
'Application.Wait (Now + TimeValue("0:00:02"))
'
''IE.Document.getElementById("l1d46017-7740-4290-9edd-f114a54099af").Click
''IE.Document.getElementById("c794efd6-769d-4c15-a58d-3de61ea30b90").Click
''IE.Document.getElementById("d853f9df-30ff-4991-99cd-bf271b52d318").Click
''IE.Document.getElementById("menu-actions").Click
''IE.Document.getElementsByTagName("input")(2).Click

 

''on selectionne le champs Titre et on définit le texte que l'on souhaite placer à l'intérieur
'IE.document.getElementById("titre").Value = "P1"
''on appuie sur entrer
'Application.SendKeys "~", True
''on attend que la page s'actualise
'Application.Wait (Now + TimeValue("0:00:01"))



'On pointe la Zone nom et on définit le texte que l'on souhaite placer à l'intérieur
IE.document.getElementById("nom").Value = Sheets("Accueil").Cells(26, 2)




'On pointe la Zone prenom et on définit le texte que l'on souhaite placer à l'intérieur
IE.document.getElementById("prenom").Value = Sheets("Accueil").Cells(28, 2)




'On pointe la Zone telephone et on définit le texte que l'on souhaite placer à l'intérieur
IE.document.getElementById("telephone").Value = Sheets("Accueil").Cells(29, 2)



'On pointe la Zone email et on définit le texte que l'on souhaite placer à l'intérieur
IE.document.getElementById("email").Value = Sheets("Accueil").Cells(30, 2)




'On pointe la Zone Zone N° et libellé de la voie et on définit le texte que l'on souhaite placer à l'intérieur
IE.document.getElementById("adr1").Value = Sheets("Accueil").Cells(40, 2)



'On pointe la Zone Complément d'adresse et on définit le texte que l'on souhaite placer à l'intérieur
IE.document.getElementById("adr2").Value = Sheets("Accueil").Cells(40, 2)


'On pointe la Zone Service distribution et on définit le texte que l'on souhaite placer à l'intérieur
IE.document.getElementById("adr3").Value = Sheets("Accueil").Cells(40, 2)


'On pointe la Zone Code Postal et on définit le texte que l'on souhaite placer à l'intérieur
IE.document.getElementById("cp").Value = Sheets("Accueil").Cells(40, 2)



'On pointe la Zone Ville et on définit le texte que l'on souhaite placer à l'intérieur
IE.document.getElementById("ville").Value = Sheets("Accueil").Cells(40, 2)



''On pointe la Zone Pays et on définit le texte que l'on souhaite placer à l'intérieur
'IE.Document.getElementById("s84eb46d-597d-4b56-9ef4-7199858b79d9").Value = Sheets("Accueil").Cells(40, 2)
''on selectionne le champs
'IE.Document.getElementById("s84eb46d-597d-4b56-9ef4-7199858b79d9").Select
''on appuie sur entrer
'Application.SendKeys "~", True
''on attend que la page s'actualise
'Application.Wait (Now + TimeValue("0:00:01"))


'On pointe la Zone Date de naissance et on définit le texte que l'on souhaite placer à l'intérieur
IE.document.getElementById("dateNaiss").Value = Sheets("Accueil").Cells(40, 2)


'On pointe la Zone Nom de naissance et on définit le texte que l'on souhaite placer à l'intérieur
IE.document.getElementById("nomNaiss").Value = Sheets("Accueil").Cells(40, 2)



'On pointe la Zone Lieu de naissance et on définit le texte que l'on souhaite placer à l'intérieur
IE.document.getElementById("lieuNaiss").Value = Sheets("Accueil").Cells(40, 2)



'On pointe la Zone Dépt. de naissance et on définit le texte que l'on souhaite placer à l'intérieur
IE.document.getElementById("deptNaiss").Value = Sheets("Accueil").Cells(40, 2)


'
''On pointe la Zone Pays de naissance et on définit le texte que l'on souhaite placer à l'intérieur
'IE.Document.getElementById("baa1c3a3-8c0b-46e4-b820-3342d5cbd459").Value = Sheets("Accueil").Cells(40, 2)
''on selectionne le champs
'IE.Document.getElementById("baa1c3a3-8c0b-46e4-b820-3342d5cbd459").Select
''on appuie sur entrer
'Application.SendKeys "~", True
''on attend que la page s'actualise
'Application.Wait (Now + TimeValue("0:00:01"))
'
'
''On pointe la Zone Pays nationalité et on définit le texte que l'on souhaite placer à l'intérieur
'IE.Document.getElementById("u217bec5-acb7-4103-a7ac-1fc85fa9dcfc").Value = Sheets("Accueil").Cells(40, 2)
''on selectionne le champs
'IE.Document.getElementById("u217bec5-acb7-4103-a7ac-1fc85fa9dcfc").Select
''on appuie sur entrer
'Application.SendKeys "~", True
''on attend que la page s'actualise
'Application.Wait (Now + TimeValue("0:00:01"))
'
'
''On pointe la Zone Situation familiale et on définit le texte que l'on souhaite placer à l'intérieur
'IE.Document.getElementById("wcb2d27c-aced-4525-b5f0-d7f591dcc004").Value = Sheets("Accueil").Cells(40, 2)
''on selectionne le champs
'IE.Document.getElementById("wcb2d27c-aced-4525-b5f0-d7f591dcc004").Select
''on appuie sur entrer
'Application.SendKeys "~", True
''on attend que la page s'actualise
'Application.Wait (Now + TimeValue("0:00:01"))


'On pointe la Zone Date d'entrée et on définit le texte que l'on souhaite placer à l'intérieur
IE.document.getElementById("date_entree").Value = Sheets("Accueil").Cells(40, 2)



'On pointe la Zone Fin période d'essai et on définit le texte que l'on souhaite placer à l'intérieur
IE.document.getElementById("dateFinEssai").Value = Sheets("Accueil").Cells(40, 2)



''On pointe la Zone Motif d'entrée et on définit le texte que l'on souhaite placer à l'intérieur
'IE.Document.getElementById("i6aefb01-832e-4310-b394-abddf438c764").Value = Sheets("Accueil").Cells(40, 2)
''on selectionne le champs
'IE.Document.getElementById("i6aefb01-832e-4310-b394-abddf438c764").Select
''on appuie sur entrer
'Application.SendKeys "~", True
''on attend que la page s'actualise
'Application.Wait (Now + TimeValue("0:00:01"))


'On pointe la Zone Date de sortie et on définit le texte que l'on souhaite placer à l'intérieur
IE.document.getElementById("date_sortie").Value = Sheets("Accueil").Cells(40, 2)



''On pointe la Zone Motif de sortie et on définit le texte que l'on souhaite placer à l'intérieur
'IE.Document.getElementById("i96cd101-35a2-4140-8c78-021decdc4275").Value = Sheets("Accueil").Cells(40, 2)
''on selectionne le champs
'IE.Document.getElementById("i96cd101-35a2-4140-8c78-021decdc4275").Select
''on appuie sur entrer
'Application.SendKeys "~", True
''on attend que la page s'actualise
'Application.Wait (Now + TimeValue("0:00:01"))


'On pointe la Zone N° Sécurité Sociale et on définit le texte que l'on souhaite placer à l'intérieur
IE.document.getElementById("ss").Value = Sheets("Accueil").Cells(40, 2)



''On pointe la Zone Nature de l'emploi et on définit le texte que l'on souhaite placer à l'intérieur
'IE.Document.getElementById("tfff6caa-e5a6-4a96-a19b-8156f3bacb8b").Value = Sheets("Accueil").Cells(40, 2)
''on selectionne le champs
'IE.Document.getElementById("tfff6caa-e5a6-4a96-a19b-8156f3bacb8b").Select
''on appuie sur entrer
'Application.SendKeys "~", True
''on attend que la page s'actualise
'Application.Wait (Now + TimeValue("0:00:01"))
'
'
''On pointe la Zone Type de contrat et on définit le texte que l'on souhaite placer à l'intérieur
'IE.Document.getElementById("i42b072e-ec66-4dc0-a352-558315ff3b7c").Value = Sheets("Accueil").Cells(40, 2)
''on selectionne le champs
'IE.Document.getElementById("i42b072e-ec66-4dc0-a352-558315ff3b7c").Select
''on appuie sur entrer
'Application.SendKeys "~", True
''on attend que la page s'actualise
'Application.Wait (Now + TimeValue("0:00:01"))
'
'
''On pointe la Zone Contrat et on définit le texte que l'on souhaite placer à l'intérieur
'IE.Document.getElementById("z960ba6f-03b0-4413-88cc-a0646ef67742").Value = Sheets("Accueil").Cells(40, 2)
''on selectionne le champs
'IE.Document.getElementById("z960ba6f-03b0-4413-88cc-a0646ef67742").Select
''on appuie sur entrer
'Application.SendKeys "~", True
''on attend que la page s'actualise
'Application.Wait (Now + TimeValue("0:00:01"))
'
'
''On pointe la Zone Catégorie et on définit le texte que l'on souhaite placer à l'intérieur
'IE.Document.getElementById("z7dbafca-dde2-4533-9f0f-96d4aad1d117").Value = Sheets("Accueil").Cells(40, 2)
''on selectionne le champs
'IE.Document.getElementById("z7dbafca-dde2-4533-9f0f-96d4aad1d117").Select
''on appuie sur entrer
'Application.SendKeys "~", True
''on attend que la page s'actualise
'Application.Wait (Now + TimeValue("0:00:01"))
'
'
''On pointe la Zone Condition d'emploi et on définit le texte que l'on souhaite placer à l'intérieur
'IE.Document.getElementById("r27a3f35-adbe-439b-8f94-2983ecabdff0").Value = Sheets("Accueil").Cells(40, 2)
''on selectionne le champs
'IE.Document.getElementById("r27a3f35-adbe-439b-8f94-2983ecabdff0").Select
''on appuie sur entrer
'Application.SendKeys "~", True
''on attend que la page s'actualise
'Application.Wait (Now + TimeValue("0:00:01"))


'On pointe la Zone CP ANCIENNETE et on définit le texte que l'on souhaite placer à l'intérieur
IE.document.getElementById("ind1").Value = Sheets("Accueil").Cells(40, 2)



'On pointe la Zone DATE DE FIN CONTRAT et on définit le texte que l'on souhaite placer à l'intérieur
IE.document.getElementById("ind2").Value = Sheets("Accueil").Cells(40, 2)



''On pointe la Zone Coefficient et on définit le texte que l'on souhaite placer à l'intérieur
'IE.document.getElementById("coefficient").Value = Sheets("Accueil").Cells(40, 2)
''on selectionne le champs
'IE.document.getElementById("coefficient").Select
''on appuie sur entrer
'Application.SendKeys "~", True
''on attend que la page s'actualise
'Application.Wait (Now + TimeValue("0:00:01"))
'
'
''On pointe la Zone Echelon et on définit le texte que l'on souhaite placer à l'intérieur
'IE.Document.getElementById("d7bb59c9-8157-4601-b4f4-03e9f96b024f").Value = Sheets("Accueil").Cells(40, 2)
''on selectionne le champs
'IE.Document.getElementById("d7bb59c9-8157-4601-b4f4-03e9f96b024f").Select
''on appuie sur entrer
'Application.SendKeys "~", True
''on attend que la page s'actualise
'Application.Wait (Now + TimeValue("0:00:01"))
'
'
''On pointe la Zone Service et on définit le texte que l'on souhaite placer à l'intérieur
'IE.Document.getElementById("a64e4f88-aadd-4ce5-aa8b-d5b8bfc9f271").Value = Sheets("Accueil").Cells(40, 2)
''on selectionne le champs
'IE.Document.getElementById("a64e4f88-aadd-4ce5-aa8b-d5b8bfc9f271").Select
''on appuie sur entrer
'Application.SendKeys "~", True
''on attend que la page s'actualise
'Application.Wait (Now + TimeValue("0:00:01"))


'On pointe la Zone IBAN et on définit le texte que l'on souhaite placer à l'intérieur
IE.document.getElementById("IBAN").Value = Sheets("Accueil").Cells(40, 2)



'On pointe la Zone BIC et on définit le texte que l'on souhaite placer à l'intérieur
IE.document.getElementById("BIC").Value = Sheets("Accueil").Cells(40, 2)



'On pointe la Zone Banque et on définit le texte que l'on souhaite placer à l'intérieur
IE.document.getElementById("banque").Value = Sheets("Accueil").Cells(40, 2)


''On pointe la Zone Réglement par et on définit le texte que l'on souhaite placer à l'intérieur
'IE.Document.getElementById("e740c93c-074f-4d2d-8a0d-1305d5499ad6").Value = Sheets("Accueil").Cells(40, 2)
''on selectionne le champs
'IE.Document.getElementById("e740c93c-074f-4d2d-8a0d-1305d5499ad6").Select
''on appuie sur entrer
'Application.SendKeys "~", True
''on attend que la page s'actualise
'Application.Wait (Now + TimeValue("0:00:01"))

  End If

End Sub
